document.addEventListener('DOMContentLoaded', function () {
    const memory = document.getElementById('tab_memory');

    const cartes = [
        {id: 1, nom: "anneau", image: 'Fonctionnement_memory/images/anneau.jpeg'},
        {id: 2, nom: "anneau", image: 'Fonctionnement_memory/images/anneau.jpeg'},
        {id: 3, nom: "chaise", image: 'Fonctionnement_memory/images/chaise.jpeg'},
        {id: 4, nom: "chaise", image: 'Fonctionnement_memory/images/chaise.jpeg'},
        {id: 5, nom: "statue", image: 'Fonctionnement_memory/images/statue.jpeg'},
        {id: 6, nom: "statue", image: 'Fonctionnement_memory/images/statue.jpeg'},
        {id: 7, nom: "voiture", image: 'Fonctionnement_memory/images/voiture.jpeg'},
        {id: 8, nom: "voiture", image: 'Fonctionnement_memory/images/voiture.jpeg'},
        {id: 9, nom: "chapeau", image: 'Fonctionnement_memory/images/chapeau.jpeg'},
        {id: 10, nom: "chapeau", image: 'Fonctionnement_memory/images/chapeau.jpeg'},
    ];

    // Fonction pour mélanger le tableau de cartes
    function melangerCartes(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }
    
    // Mélange les cartes
    melangerCartes(cartes);

    let cartechoisie1 = "";
    let cartechoisie2 = "";
    let imageCarte1 = "";
    let imageCarte2 = "";
    let U = 0;

    cartes.forEach(function(carte, index) {
        const nouvelleCarte = document.createElement("div");
        nouvelleCarte.classList.add("carte");
        
        memory.appendChild(nouvelleCarte);
        nouvelleCarte.innerHTML = `<p><i>${index + 1}</i></p>`; // Utilise l'index pour obtenir un numéro unique

        nouvelleCarte.addEventListener("click", function() {
            // Actions à effectuer lors du clic sur une carte
            console.log("La carte avec le nom '" + carte.nom + "' a été cliquée.");
            alert("La carte avec le nom '" + carte.nom + "' a été cliquée.");
            nouvelleCarte.style.backgroundImage = `url('${carte.image}')`;
    
            if (cartechoisie1 == "") {
                // Aucune carte n'a été choisie auparavant
                cartechoisie1 = nouvelleCarte;
                imageCarte1 = nouvelleCarte.style.backgroundImage = `url('${carte.image}')`;
            } else if (cartechoisie2 == "") {
                // Une carte a déjà été choisie
                cartechoisie2 = nouvelleCarte;
                imageCarte2 = nouvelleCarte.style.backgroundImage = `url('${carte.image}')`;

                // Vérifie si les deux cartes choisies sont identiques
                if (imageCarte1 === imageCarte2) {
                     // Supprime les écouteurs d'événements pour les deux cartes
                    alert("Bravo, vous avez trouvé une paire !");
                    cartechoisie1.removeEventListener("click", arguments.callee);
                    console.log("Carte 1 bloqué")
                    cartechoisie2.removeEventListener("click", arguments.callee);
                    console.log("Carte 2 bloqué")
                    cartechoisie1 = "";
                    cartechoisie2 = "";
                    U++;
                        if(U == 5) {
                            alert("Le jeu est fini")
                        }
                } else {

                    alert("Désolé, les cartes ne correspondent pas.");
                    // Réinitialise les choix après un court délai
                    setTimeout(() => {
                        cartechoisie1.style.backgroundImage = "";
                        console.log("La premiere carte reinsilisé")
                        cartechoisie2.style.backgroundImage = "";
                        console.log("La deuxième carte reinsilisé")
                        cartechoisie1 = "";
                        cartechoisie2 = "";
                    }, 500)
                }
            }
        });
    });
    


});
